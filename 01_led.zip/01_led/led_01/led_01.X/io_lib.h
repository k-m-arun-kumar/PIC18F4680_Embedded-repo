/**************************************************************************
   FILE          :    io_lib.h
 
   PURPOSE       :     I/O library
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
	
  CHANGE LOGS     :
	   
 **************************************************************************/
 
 /* to avoid this header file to be included more than once, conditional directive is used  */
#ifndef _IO_LIB_H
#define _IO_LIB_H

 /* ---------------------- macro defination ------------------------------------------------ */
/* digital IO pin or port as input */ 
#define INPUT_PORT_OR_PIN              (1)
/* digital IO pin or port as output */ 
#define OUTPUT_PORT_OR_PIN             (0)

/* digital IO as whole port */
#define PORT_INFO                      (8)

 // RA0 RA1 RA2 RA3 RA5 RE0 RE1 RE2 RB1 RB4 RB0 are all of analog multiplexed IO pins are digital IO
#define NO_ANALOGS                     (0x0F) 
 // RA0 RA1 RA2 RA3 RA5 RE0 RE1 RE2 RB1 RB4 RB0 are all analog multiplexed IO pins are analog IO  
#define ALL_ANALOG                      (0x00)  
 //  RA0 RA1 RA2 RA3 RA5 RE0 RE1 RE2 RB1 RB4 pins are analog IO and RB0 are digital IO         
#define AN0_TO_AN9                      (0x05) 
// RA0 RA1 RA2 RA3 RA5 RE0 RE1 RE2 RB1 pins are analog IO and RB4 and RB0 are digital IO           
#define AN0_TO_AN8                       (0x06) 
// RA0 RA1 RA2 RA3 RA5 RE0 RE1 RE2  pins are analog and RB1 RB4 RB0 are digital IO               
#define AN0_TO_AN7                       (0x07)  
 // RA0 RA1 RA2 RA3 RA5 RE0 RE1  pins are analog  and RE2 RB1 RB4 RB0 are digital IO                  
#define AN0_TO_AN6                       (0x08)  
 // RA0 RA1 RA2 RA3 RA5 RE0  pins are analog  and RE1 RE2 RB1 RB4 RB0 are digital IO                    
#define AN0_TO_AN5                       (0x09)  
// RA0 RA1 RA2 RA3 RA5  pins are analog  and RE0 RE1 RE2 RB1 RB4 RB0 are digital IO                      
#define AN0_TO_AN4                       (0x0A)
 // RA0 RA1 RA2 RA3 pins are analog and RA5 RE0 RE1 RE2 RB1 RB4 RB0 are digital IO
#define AN0_TO_AN3                       (0x0B) 
 // RA0 RA1 RA2 pins are analog and RA3 RA5 RE0 RE1 RE2 RB1 RB4 RB0 are digital IO
#define AN0_TO_AN2                       (0x0C) 
 // RA0 RA1  pins are analog  and RA2 RA3 RA5 RE0 RE1 RE2 RB1 RB4 RB0 are digital IO
#define AN0_TO_AN1                      (0x0D) 
 // RA0 pins are analog  and RA1 RA2 RA3 RA5 RE0 RE1 RE2 RB1 RB4 RB0 are digital IO
#define AN0                             (0x0E)  
 
// analog Range 0-Vdd
#define VSS_VDD                        (0x00)   
// analog Range VrefL-VrefH           
#define VREF_VREF                      (0x30)  
 // analog Range VrefL-Vdd           
#define VREF_VDD                       (0x20)  
 // analog Range 0-VrefH           
#define VSS_VREF                      (0x10)

 /* ---------------------- data type defination --------------------------------------------- */
 typedef struct {
	 unsigned int ad_port_conf : 4;
     unsigned int an_vref_conf : 2;
     unsigned int : 2;	 
 } ad_port_ctrl_conf_types;
 /* -------------------- public variable prototype --------------------------------------- */
 
 /* -------------------- public function prototype --------------------------------------- */
 
uint_8 Set_Port_or_Pin_Tris( volatile uchar *const tris_port, const uint_8 port_bit_pos, const uint_8 set_tris );
uchar Get_Port_or_Pin_Tris(volatile const uchar *const tris_port, const uint_8 port_bit_pos);
uint_8 Output_Port_or_Pin_State(volatile uchar *const state_port, const uint_8 port_bit_pos, const uint_8 set_state);
uchar Input_Port_or_Pin_State(volatile const uchar *const state_port, const uint_8 port_bit_pos);
uint_8 Set_IO_Port_Ctrl(const uint_8 set_ad_port_ctrl_conf );
uchar Get_IO_Port_Ctrl();
uint_8 Init_State(volatile uchar *const tris_port);  
#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
