/* ********************************************************************
FILE                   : osc_lib.c

PROGRAM DESCRIPTION    :  oscilation library                         						  				 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :                         										
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "io_conf.h"
#include "osc_lib.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : main

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/
uint_8 Set_Osc_Ctrl(const unsigned int set_osc_ctrl_conf  )
{
	uint_8 ret_state = SUCCESS;
    void *set_osc_ctrl_ptr = &set_osc_ctrl_conf; 
	osc_ctrl_conf_types *osc_ctrl_conf_ptr = (osc_ctrl_conf_types *)set_osc_ctrl_ptr;
	
    OSCCON =  osc_ctrl_conf_ptr->power_mode << 7 | osc_ctrl_conf_ptr->intr_osc_freq << 4 | osc_ctrl_conf_ptr->system_clk;	
	return ret_state;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
