/**************************************************************************
   FILE          :    appl_conf.h
 
   PURPOSE       :   main application configuration Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_CONF_H
 #define _APPL_CONF_H 
 
/* -------------------------------- debug conf -----------------------------------------*/
#define TRACE                                   (1U)
#define TRACE_ERROR                             (2U)

/*------------------------------- LCD disp conf ------------------------------------------*/
 #define LCD_DISP_ERR_LINE_NUM                 (NUM_LINE4) 
 
/* -------------------------------Timer state conf ---------------------------------------*/

/* ---------------------------------- ADC channel && input signal val conf -------------- */



/* ------------------------------- application conf --------------------------------------*/

#define REQ_TIME_LED1_ON_IN_MS            (3000)
#define REQ_TIME_LED1_OFF_IN_MS           (3000)

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
