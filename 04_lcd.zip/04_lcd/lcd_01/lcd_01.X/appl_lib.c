/* ********************************************************************
FILE                   : appl_lib.c

PROGRAM DESCRIPTION    : application library                          						  				 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :                         										
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "appl_lib.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : Write_Bit

DESCRIPTION     : write bit valve to data's bit, without affecting other bits of data .
                . 0 is the least bit pos and 7 is the most bit pos 

INPUT          : 

OUTPUT         : none

NOTE           : 
-*------------------------------------------------------------*/
uint_8 Write_Bit_in_Data(volatile uchar *const data_ptr, const uint_8 bit_pos, const uint_8 set_bit_val )
{
	   uint_8 ret_state = SUCCESS;
	   switch(set_bit_val)
	   {
		   case 0:
		      Clear_Bit_in_Data(data_ptr, bit_pos ); 
		   break;
           case 1:			
              Set_Bit_in_Data(data_ptr, bit_pos);
           break;
		   default:
             ret_state = FAILURE;		   
       }
       return ret_state;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
