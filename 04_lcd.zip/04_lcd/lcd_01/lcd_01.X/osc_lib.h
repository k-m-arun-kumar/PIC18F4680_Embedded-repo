/**************************************************************************
   FILE          :    osc_lib.h
 
   PURPOSE       :    oscillator library Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _OSC_LIB_H
 #define _OSC_LIB_H
 
 /* ---------------------- macro defination ------------------------------------------------ */ 
 //system clock select as Primary oscillator
 #define SYSTEM_CLK_PRIMARY_OSC                       (0x00)
 //system clock select as Timer1 oscillator
 #define SYSTEM_CLK_TMR1                              (0x01)
 //system clock select as Internal oscillator block
 #define SYSTEM_CLK_INTR_OSC                          (0x02)
 
  //Internal Oscillator Frequency = 31 KHz(from either INTOSC/256 or INTRC directly) 
 #define INTR_OSC_FREQ_31Khz                          (0x00)
 //Internal Oscillator Frequency = 125 KHz             
 #define INTR_OSC_FREQ_125Khz                         (0x10)
 //Internal Oscillator Frequency = 250 KHz   
  #define INTR_OSC_FREQ_250Khz                        (0x20)
 //Internal Oscillator Frequency = 500 KHz             
 #define INTR_OSC_FREQ_500Khz                         (0x30)
 //Internal Oscillator Frequency = 1MHz   
 #define INTR_OSC_FREQ_1Mhz                           (0x40) 
  //Internal Oscillator Frequency = 2MHz   
 #define INTR_OSC_FREQ_2Mhz                           (0x50) 
 //Internal Oscillator Frequency = 4MHz   
 #define INTR_OSC_FREQ_4Mhz                           (0x60) 
  //Internal Oscillator Frequency = 8MHz   
 #define INTR_OSC_FREQ_8Mhz                           (0x70)
 
//Device enters Idle mode when SLEEP instruction is executed
#define IDLE_MODE_ENABLE                              (0x80)  
//Device enters sleep mode when SLEEP instruction is executed
#define SLEEP_MODE_ENABLE                             (0x00) 
  
//Oscillator start-up time-out timer has expired; primary oscillator is running
#define OST_EXPIRED                                     (1)
 // Oscillator start-up time-out timer is running; primary oscillator is not ready 
#define OST_RUNNING                                     (0)

//INTOSC frequency is stable and the frequency is provided by one of the RC modes
#define  INTOSC_FREQ_STABLE                                  (1) 
//INTOSC frequency is not stable
#define  INTOSC_FREQ_NOT_STABLE                              (0)
 
 /* ---------------------- data type defination --------------------------------------------- */
 typedef struct { 
    unsigned int system_clk: 2;             
	unsigned int iofs: 1;
	unsigned int osts: 1;
	unsigned int intr_osc_freq: 3;
    unsigned int power_mode : 1;	              
 } osc_ctrl_conf_types;
 
 
 /* -------------------- public variable prototype --------------------------------------- */
 
 /* -------------------- public function prototype --------------------------------------- */
  uint_8 Set_Osc_Ctrl(const unsigned int const osc_ctrl_conf);
 
#endif 

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/ 
