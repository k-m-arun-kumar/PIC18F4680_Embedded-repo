/**************************************************************************
   FILE          :    appl_lib.h
 
   PURPOSE       :   application library Header
 
   AUTHOR        :    K.M. Arun Kumar alias Arunkumar Murugeswaran
 
  KNOWN BUGS     :
	
  NOTE           :   data_ptr points to 8 bit data
  
  CHANGE LOGS    :
	   
 **************************************************************************/
 
 #ifndef _APPL_LIB_H
 #define _APPL_LIB_H 
 
  /* Bit Operation macros */
     /* Set bit pos  in  data   */
#define Set_Bit_in_Data(data_ptr , bit_pos)                         (*(data_ptr) |=   (1<<(bit_pos)))     
      /* Clear bit pos in  data */ 
#define Clear_Bit_in_Data(data_ptr ,bit_pos)                         (*(data_ptr) &= (~(1<<(bit_pos))))      
    /* flip bit pos in  data  */ 
#define Toggle_Bit_in_Data(data_ptr , bit_pos)                       (*(data_ptr) ^=   (1<<(bit_pos))) 
   /* check status of data in bit */ 
#define Check_Bit_Is_Status_in_Data(data_ptr ,bit_pos)                ((*(data_ptr) >> bit_pos) & 0x01)  
    /* Test if bit pos in  data  is set   */
#define Test_Bit_Is_Set_in_Data(data_ptr ,bit_pos)                    (*(data_ptr) & (1<<bit_pos))       
   /* Test if bit pos in  data is clear */  
#define Test_Bit_Is_Clear_in_Data(data_ptr ,bit_pos)                  (!(*(data_ptr) & (1<<bit_pos))) 

uint_8 Write_Bit_in_Data(volatile uchar  *const data_ptr, const uint_8 bit_pos, const uint_8 set_bit_val );

#endif

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
