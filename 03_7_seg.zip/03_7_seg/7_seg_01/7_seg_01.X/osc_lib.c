/* ********************************************************************
FILE                   : osc_lib.c

PROGRAM DESCRIPTION    :  oscilator library                         						  				 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :                         										
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "main.h"
#include "io_conf.h"
#include "osc_lib.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : Set_Osc_Ctrl

DESCRIPTION    : configures OSCCON reg, which oscillator control reg, with a given set_osc_ctrl_conf
								
INPUT          : set_osc_ctrl_conf datas for Idle Enable bit, Internal Oscillator Frequency Select, or/and System Clock Select bits

OUTPUT         :  success or failure of set Set_Osc_Ctrl

NOTE           : OSCCON reg has datas for Idle Enable bit, Internal Oscillator Frequency Select, Oscillator Start-up Time-out Status bit,
                 INTOSC Frequency Stable bit, and System Clock Select bits
-*------------------------------------------------------------*/
uint_8 Set_Osc_Ctrl(const unsigned int set_osc_ctrl_conf  )
{
	uint_8 ret_state = SUCCESS;
    void *set_osc_ctrl_ptr = &set_osc_ctrl_conf; 
	osc_ctrl_conf_types *osc_ctrl_conf_ptr = (osc_ctrl_conf_types *)set_osc_ctrl_ptr;
	
    OSCCON =  osc_ctrl_conf_ptr->power_mode << 7 | osc_ctrl_conf_ptr->intr_osc_freq << 4 | osc_ctrl_conf_ptr->system_clk;	
	return ret_state;
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Get_Osc_Ctrl

DESCRIPTION    : returns the OSCCON register. 
								
INPUT          : 

OUTPUT         :  contents of OSCCON register.

NOTE           : OSCCON reg has datas for Idle Enable bit, Internal Oscillator Frequency Select, Oscillator Start-up Time-out Status bit,
                 INTOSC Frequency Stable bit, and System Clock Select bits
-*------------------------------------------------------------*/
uint_8 Get_Osc_Ctrl()
{
	return OSCCON;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
