/* ********************************************************************
FILE                   : main.c

PROGRAM DESCRIPTION    : increment digit and roll over for every SW_INC press 
                         						  				 
	 
AUTHOR                :K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : developed with uc PIC18F4680 on XC8 compiler(v1.45) in MPLAB - X IDE (v4.01) and simulated in proteus 8.3 
                        Tested OK.
                    1 : Make sure that _XTAL_FREQ and INTR_OSC_FREQ_<X>Hz are same and SYSTEM_CLK_PRIMARY_OSC is selected 
                    2 : make sure that led1 pin is configured as digital pin if multiplexed with analog pin.					
                                    
CHANGE LOGS           : 

*****************************************************************************/
// PIC18F4680 Configuration Bit Settings
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
// 'C' source line config statements

// CONFIG1

// PIC18F4680 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1H
#pragma config OSC = IRCIO67    // Oscillator Selection bits (Internal oscillator block, port function on RA6 and RA7)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = ON        // Internal/External Oscillator Switchover bit (Oscillator Switchover mode enabled)

// CONFIG2L
#pragma config PWRT = ON        // Power-up Timer Enable bit (PWRT enabled)
#pragma config BOREN = OFF     // Brown-out Reset Enable bits (Brown-out Reset is diabled in Hardware and software disabled )
#pragma config BORV = 3         // Brown-out Reset Voltage bits (VBOR set to 2.1V)

// CONFIG2H
#pragma config WDT = OFF         // Watchdog Timer Enable bit (WDT disabled)
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config PBADEN = OFF     // PORTB A/D Enable bit (PORTB<4:0> pins are configured as digital I/O on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer 1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE = OFF       // MCLR Pin Enable bit (MCLR pin disabled; RE3 input pin enabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = OFF         // Single-Supply ICSP Enable bit (Single-Supply ICSP disabled)
#pragma config BBSIZ = 1024     // Boot Block Size Select bits (1K words (8K bytes) Boot Block)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode)) 

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (008000-00BFFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (00C000-00FFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (008000-00BFFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (00C000-00FFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot block (000000-0007FFh) not protected from table reads executed in other blocks)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include "osc_lib.h" 
#include "io_lib.h"
#include "port.h"
#include "io_conf.h"
#include "appl_conf.h"

#define RADIX_DECIMAL           (10)

value_types to_disp;
volatile  uchar *state_port_led, *state_port_sw;
static uint_8 System_Init();

/*------------------------------------------------------------*-
FUNCTION NAME  : 

DESCRIPTION    :
								
INPUT          : none

OUTPUT         : 

NOTE           : 
-*------------------------------------------------------------*/

void main()
{
	uint_8 ret_state;
	const uchar SEGMENT_MAP[RADIX_DECIMAL] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F,0x6F};
	uchar digit = 0;
	
    if((ret_state = System_Init()) != SUCCESS)
	{
		return;
	} 
	while(1)
	{ 
        if((ret_state = Input_Port_or_Pin_State(&SW_INC_STATE_PORT, SW_INC_PIN_BIT_POS)) == KEY_PRESSED)
			__delay_ms(SWITCH_DEBOUNCE_IN_MS);
		if((ret_state = Input_Port_or_Pin_State(&SW_INC_STATE_PORT, SW_INC_PIN_BIT_POS)) == KEY_PRESSED)
		{
			while((ret_state = Input_Port_or_Pin_State(&SW_INC_STATE_PORT, SW_INC_PIN_BIT_POS)) == KEY_PRESSED);
			if(++digit >= RADIX_DECIMAL)
			{
				digit = 0;
			}
			Output_Port_or_Pin_State(&SEG_STATE_PORT, SEG_PORT_BIT_POS, SEGMENT_MAP[digit] );
		}
    }
}
/*------------------------------------------------------------*-
FUNCTION NAME  : System_Init

DESCRIPTION    : system initialization
								
INPUT          : none

OUTPUT         : success or failure of system initialization 

NOTE           : 
-*------------------------------------------------------------*/
static uint_8 System_Init()
{
	 volatile unsigned int ret_state;
	 void *get_ad_port_ctrl_ptr = NULL; 
	 ad_port_ctrl_conf_types *ad_port_ctrl_conf_ptr = NULL;
	 
	 Init_State(&SEG_TRIS_PORT);
	 Init_State(&SW_INC_TRIS_PORT);
	 
	 Set_Osc_Ctrl(INTR_OSC_FREQ_8Mhz | SYSTEM_CLK_PRIMARY_OSC | SLEEP_MODE_ENABLE ); 
	 Set_IO_Port_Ctrl(NO_ANALOGS);  // config all ANALOG Multiplexed IO ports as digital pin
	 ret_state = Get_IO_Port_Ctrl();
	 get_ad_port_ctrl_ptr = &ret_state;
	 ad_port_ctrl_conf_ptr = (ad_port_ctrl_conf_types *)get_ad_port_ctrl_ptr;
	 if(ad_port_ctrl_conf_ptr->ad_port_conf != NO_ANALOGS)
	 {
		 return FAILURE;
	 }  
	 Set_Port_or_Pin_Tris(&SEG_TRIS_PORT, SEG_PORT_BIT_POS, OUTPUT_PORT_OR_PIN ); 
	 if((ret_state = Get_Port_or_Pin_Tris(&SEG_TRIS_PORT,SEG_PORT_BIT_POS)) != OUTPUT_PORT_OR_PIN )
	 {
		 //error: SEG_TRIS_PORT was not configured as output
		 return FAILURE;
	 }
	 Set_Port_or_Pin_Tris(&SW_INC_TRIS_PORT, SW_INC_PIN_BIT_POS, INPUT_PORT_OR_PIN ); 
	 if((ret_state = Get_Port_or_Pin_Tris(&SW_INC_TRIS_PORT, SW_INC_PIN_BIT_POS)) != INPUT_PORT_OR_PIN )
	 {
		 //error: SW_INC_TRIS_PORT was not configured  as input
		 return FAILURE;
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	 
