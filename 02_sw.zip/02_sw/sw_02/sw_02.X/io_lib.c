/* ********************************************************************
FILE                   : io_lib.c

PROGRAM DESCRIPTION    :  IO based library function
                         						  				 
	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  						
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "main.h"
#include "appl_lib.h"
#include "io_lib.h"

/*------------------------------------------------------------*-
FUNCTION NAME  : Set_Port_or_Pin_Tris

DESCRIPTION    :  configures tris_port at particular bit position(0 to 7) given by port_bit_pos as either input or output given by set_tris
                  if port_bit_pos >= max data bit ie 8, then it configures whole tris_port as either input or output, given by set_tris.  
								
INPUT          : tris_port = TRIS<x> register , port_bit_pos = bit position in TRIS<x> register  and set_tris = INPUT or output

OUTPUT         : success or failure of conf IO 

NOTE           : tris_port  = TRIS<x> register, where x = A,B,C,D,E
-*------------------------------------------------------------*/
uint_8 Set_Port_or_Pin_Tris( volatile uchar *const tris_port, const uint_8 port_bit_pos, const uint_8 set_tris )
{	
     uint_8 ret_state = SUCCESS;	 
     
	 if(port_bit_pos >= PORT_INFO)
	 {
		 switch(set_tris)
		 { 
		     case INPUT_PORT_OR_PIN:			   
				 *tris_port = 0xFF;
			 break;
             case OUTPUT_PORT_OR_PIN:
               	*tris_port = 0x00;
             break;
             default:
		    	 //ERROR: invalid set TRIS info 
                ret_state = FAILURE; 				
		 }
     }
     else
	 {
    	  ret_state =  Write_Bit_in_Data(tris_port, port_bit_pos, set_tris); 
	 }
	 return ret_state;        	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Get_Port_or_Pin_Tris

DESCRIPTION    : returns as either input or output of a given tris_port at particular bit position(0 to 7) given by port_bit_pos 
                  if port_bit_pos >= max data bit ie 8, then it return as either input or output of the TRIS of a whole given tris_port.
								
INPUT          : tris_port = TRIS<x> register, port_bit_pos = bit position in TRIS<x> register  

OUTPUT         : INPUT or output 

NOTE           :  tris_port  = TRIS<x> register, where x = A,B,C,D,E
-*------------------------------------------------------------*/
unsigned char Get_Port_or_Pin_Tris(volatile const uchar *const tris_port, const uint_8 port_bit_pos)
{	
    uint_8 ret_state;
	if(port_bit_pos >= PORT_INFO)
	{
		return *tris_port;
	}
	ret_state = Check_Bit_Is_Status_in_Data(tris_port, port_bit_pos)  ;
	return ret_state;	
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Output_Port_or_Pin_State

DESCRIPTION    : configures state_port  at particular bit position(0 to 7) given by port_bit_pos as either state 0 or state 1 given by set_state
                  if port_bit_pos >= max data bit ie 8, then it configures whole state_port as given by set_state.  
								
INPUT          : state_port = LAT<x> register, port_bit_pos = bit position in state port and set_state 

OUTPUT         : success or failure of conf IO state

NOTE           : state_port  = LAT<x> register, where x = A,B,C,D,E
-*------------------------------------------------------------*/
uint_8 Output_Port_or_Pin_State(volatile uchar *const state_port, const uint_8 port_bit_pos , const uint_8 set_state )
{	
     uint_8 ret_state = SUCCESS;
	 
	 if(port_bit_pos >= PORT_INFO)
	 {
		 *state_port = set_state; 
     }
     else
	 {	 
         ret_state =  Write_Bit_in_Data(state_port, port_bit_pos, set_state);
	 }
	 return ret_state;        	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Input_Port_or_Pin_State

DESCRIPTION    : returns as either state 0 or state 1 of the state_port of a given state_port at particular bit position(0 to 7) given by port_bit_pos 
                  if port_bit_pos >= max data bit ie 8, then it return as either state 0 or state 1 of a whole given state_port.
								
INPUT          : state_port = PORT<x> register, port_bit_pos = bit position in state port 

OUTPUT         : state 0 or state 1

NOTE           : state_port  = PORT<x> register, where x = A,B,C,D,E
-*------------------------------------------------------------*/
uchar Input_Port_or_Pin_State(volatile const uchar *const state_port, const uint_8 port_bit_pos)
{	
    uint_8 ret_state;
	
	if(port_bit_pos >= PORT_INFO)
	{
	     return *state_port;
	}
	ret_state = Check_Bit_Is_Status_in_Data(state_port, port_bit_pos);        
	return ret_state;	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Set_IO_Port_Ctrl

DESCRIPTION    : configures ADCON1 register with given set_ad_port_ctrl_conf, where set_ad_port_ctrl_conf configures multiplexed analog and digital IO 
                 and voltage reference for analog inputs.
								
INPUT          :  set_ad_port_ctrl_conf configures multiplexed analog and digital IO and voltage reference for analog inputs.

OUTPUT         : success or failure of set IO Port

NOTE           : ADCON1 register, has A/D control register for conf either analog or digital IO. if analog IO then its voltage reference. 
-*------------------------------------------------------------*/
uint_8 Set_IO_Port_Ctrl(const uint_8 set_ad_port_ctrl_conf )
{	
    uint_8 ret_state = SUCCESS;
	void *set_ad_port_ctrl_ptr = &set_ad_port_ctrl_conf; 
	ad_port_ctrl_conf_types *ad_port_ctrl_conf_ptr = (ad_port_ctrl_conf_types *)set_ad_port_ctrl_ptr;
	switch(ad_port_ctrl_conf_ptr->ad_port_conf )
	{
		case NO_ANALOGS:
	       ADCON1 = ad_port_ctrl_conf_ptr->ad_port_conf; 
		break;
		default:
		   ADCON1 = ad_port_ctrl_conf_ptr->ad_port_conf | ad_port_ctrl_conf_ptr-> an_vref_conf << 4;	    
	}
	return ret_state;	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Get_IO_Port_Ctrl

DESCRIPTION    : returns the ADCON1 register, which has A/D control register for conf either analog or digital IO.
                  if analog IO then its voltage reference.  
								
INPUT          : none

OUTPUT         : returns the ADCON1 register,

NOTE           : 
-*------------------------------------------------------------*/
uchar Get_IO_Port_Ctrl()
{	
    return ADCON1;	
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Init_State

DESCRIPTION    : clear PORT and LAT SFR corresponding to tris_port
								
INPUT          : tris_port = TRIS<x> register

OUTPUT         : success or failure of Init State

NOTE           : where x = A,B,C,D,E
-*------------------------------------------------------------*/
uint_8 Init_State(volatile const uchar *const tris_port)
{	   
    uint_8 ret_state = SUCCESS;
	
	if(*tris_port == TRISA)
	{
	    PORTA = 0x00;
		LATA = 0x00; 
	}
	else if(*tris_port == TRISB)
	{
		   PORTB = 0x00;
		   LATB = 0x00; 
	}
	else if (*tris_port == TRISC)
	{
		   PORTC = 0x00;
		   LATC = 0x00; 
	}
	else if (*tris_port == TRISD)
	{
 		  PORTD = 0x00;
		   LATD = 0x00; 
	}
    else if (*tris_port == TRISE)	
	{
		   PORTE = 0x00;
		   LATE = 0x00;
	}
	else 
	{
		ret_state = FAILURE;
	}	
	return ret_state;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/	
